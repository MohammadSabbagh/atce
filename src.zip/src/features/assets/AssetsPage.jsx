import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAssets } from './useAssets';
import AssetCard from './AssetCard';
import { S } from '../../lib/strings';
import { DEPARTMENTS } from '../../lib/constants';
import './AssetsPage.scss';

export default function AssetsPage() {
  const navigate = useNavigate();
  const [typeFilter, setTypeFilter] = useState('all');
  const [deptFilter, setDeptFilter] = useState('all');
  const [search, setSearch] = useState('');

  const { assets, loading } = useAssets();

  const filtered = assets.filter((a) => {
    if (typeFilter !== 'all' && a.type !== typeFilter) return false;
    if (deptFilter !== 'all' && a.department !== deptFilter) return false;
    if (search) {
      const q = search.toLowerCase();
      return (
        a.name?.toLowerCase().includes(q) ||
        a.plate_number?.toLowerCase().includes(q) ||
        a.model?.toLowerCase().includes(q) ||
        a.assigned_to?.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="assets-page">
      <div className="assets-page__header">
        <h1 className="assets-page__title">{S.assetsTitle}</h1>
        <button
          className="assets-page__add-btn"
          onClick={() => navigate('/assets/new')}
        >
          {S.assetsAddNew}
        </button>
      </div>

      <div className="assets-page__search-wrap">
        <input
          className="assets-page__search"
          type="text"
          placeholder={S.assetsSearchPlaceholder}
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          dir="rtl"
        />
      </div>

      <div className="assets-page__filters">
        <div className="assets-page__filter-group">
          {['all', 'car', 'other'].map((t) => (
            <button
              key={t}
              className={`assets-page__chip${typeFilter === t ? ' assets-page__chip--active' : ''}`}
              onClick={() => setTypeFilter(t)}
            >
              {t === 'all' ? S.filterAll : t === 'car' ? S.assetTypeCar : S.assetTypeOther}
            </button>
          ))}
        </div>

        <div className="assets-page__filter-group assets-page__filter-group--dept">
          <button
            className={`assets-page__chip${deptFilter === 'all' ? ' assets-page__chip--active' : ''}`}
            onClick={() => setDeptFilter('all')}
          >
            {S.filterAll}
          </button>
          {DEPARTMENTS.map((d) => (
            <button
              key={d}
              className={`assets-page__chip${deptFilter === d ? ' assets-page__chip--active' : ''}`}
              onClick={() => setDeptFilter(d)}
            >
              {d}
            </button>
          ))}
        </div>
      </div>

      <div className="assets-page__list">
        {loading ? (
          Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="assets-page__skeleton" />
          ))
        ) : filtered.length === 0 ? (
          <div className="assets-page__empty">{S.assetsEmpty}</div>
        ) : (
          filtered.map((asset) => (
            <AssetCard
              key={asset.id}
              asset={asset}
              onClick={() => navigate(`/assets/${asset.id}`)}
            />
          ))
        )}
      </div>
    </div>
  );
}