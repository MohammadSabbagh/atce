// src/features/mo/MOCard.jsx
import { getMOStatusLabel, getMOStatusClass } from '@/lib/moStatusConfig';
import { formatCurrency } from '@/lib/strings';
import './MoCard.scss';

export default function MOCard({ mo, onClick }) {
  return (
    <div className="mo-card" onClick={onClick}>
      <div className="mo-card__top">
        <span className="mo-card__number">{mo.mo_number}</span>
        <span className={`mo-card__status ${getMOStatusClass(mo.status)}`}>
          {getMOStatusLabel(mo.status)}
        </span>
      </div>

      <div className="mo-card__title">{mo.title}</div>

      <div className="mo-card__bottom">
        <span className="mo-card__total">
          {formatCurrency(mo.item_price, mo.currency)}
        </span>

        <div className="mo-card__meta">
          {mo.type && (
            <span className={`mo-card__type-badge mo-card__type-badge--${mo.type}`}>
              {mo.type === 'car' ? 'مركبة' : 'أخرى'}
            </span>
          )}
          {mo.department && (
            <span className="mo-card__dept">{mo.department}</span>
          )}
        </div>

        <span className="mo-card__date">
          {mo.created_at
            ? new Date(mo.created_at).toLocaleDateString('ar-SA', {
                day: 'numeric',
                month: 'short',
              })
            : ''}
        </span>
      </div>
    </div>
  );
}