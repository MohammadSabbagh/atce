// src/features/mo/MOList.jsx
import { useNavigate } from 'react-router-dom';
import { useMOList } from './useMOList';
import MOCard from './MOCard';
import { getMOStatusLabel } from '@/lib/moStatusConfig';
import { S } from '@/lib/strings';
import './MoList.scss';

const STATUSES = ['all', 'draft', 'pending', 'approved', 'released', 'rejected', 'cancelled'];
const TYPES    = ['all', 'car', 'other'];

export default function MOList() {
  const navigate = useNavigate();
  const {
    mos,
    loading,
    statusFilter,
    typeFilter,
    setStatusFilter,
    setTypeFilter,
  } = useMOList();

  return (
    <div className="mo-list">
      <div className="mo-list__header">
        <h1 className="mo-list__title">{S.moListTitle}</h1>
        <button
          className="mo-list__add-btn"
          onClick={() => navigate('/mo/create')}
        >
          {S.moAddNew}
        </button>
      </div>

      {/* Type filter */}
      <div className="mo-list__filters">
        <div className="mo-list__filter-row">
          {TYPES.map((t) => (
            <button
              key={t}
              className={`mo-list__chip${typeFilter === t ? ' mo-list__chip--active' : ''}`}
              onClick={() => setTypeFilter(t)}
            >
              {t === 'all' ? S.filterAll : t === 'car' ? 'مركبة' : 'أخرى'}
            </button>
          ))}
        </div>

        {/* Status filter */}
        <div className="mo-list__filter-row">
          {STATUSES.map((s) => (
            <button
              key={s}
              className={`mo-list__chip${statusFilter === s ? ' mo-list__chip--active' : ''}`}
              onClick={() => setStatusFilter(s)}
            >
              {s === 'all' ? S.filterAll : getMOStatusLabel(s)}
            </button>
          ))}
        </div>
      </div>

      <div className="mo-list__body">
        {loading ? (
          Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="mo-list__skeleton" />
          ))
        ) : mos.length === 0 ? (
          <div className="mo-list__empty">{S.moEmpty}</div>
        ) : (
          mos.map((mo) => (
            <MOCard
              key={mo.id}
              mo={mo}
              onClick={() => navigate(`/mo/${mo.id}`)}
            />
          ))
        )}
      </div>
    </div>
  );
}